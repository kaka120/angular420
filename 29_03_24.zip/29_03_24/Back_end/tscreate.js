var mysql = require('mysql');

var con = mysql.createConnection({
  host: "database-1.chwiikiiuz9u.eu-north-1.rds.amazonaws.com", 
  user: "admin",
  password: "V478l#nQJAWw",
  port:"3306",
  database:"chikankari"
});

// con.connect(function(err) {
//   if (err) throw err;
//   con.query("SELECT * FROM user_details", function (err, result, fields) {
//     if (err) throw err;
//     console.log(result);
//   });
// });

const wrapper = require('node-mysql-wrapper'); 
const db = wrapper.wrap(con);

const User = {};

User.fetchAll = (result) => {
  db.ready(function(){
      db.table("user_details").findAll()
      .then((res) => {
          //db_close();
          result(null,res);
          return;
      
      })
      .catch( (err) => {
          if (err) 
          {
              result(err,null);
              return;
          }
      })
  });
};

let user_id = undefined;
  if(user_id == undefined){
      User.fetchAll((err,data) => {
          if (err){
            console.log(err.message);
          }
              
          else console.log(data);
      })
  }else{
      User.fetchOne({user_id:user_id},(err,data) => {
          if (err)
            console.log(err.message);
          else console.log(data);
      })
      
  }