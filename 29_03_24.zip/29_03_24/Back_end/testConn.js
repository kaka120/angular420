var mysql = require("mysql");

var con = mysql.createConnection({
  host: "database-1.chwiikiiuz9u.eu-north-1.rds.amazonaws.com",
  user: "admin",
  password: "V478l#nQJAWw",
  port: "3306",
  database: "chikankari",
});

const express = require("express");
const app = express();
const CONFIG = 12345;
const bodyParser = require("body-parser");
var cors = require('cors')
const router = express.Router();

const wrapper = require("node-mysql-wrapper");
const db = wrapper.wrap(con);

const User = {};

function validateUser(userObj){
    const UserSchema = Joi.object({
        user_first_name : Joi.string().required(),
        user_last_name  : Joi.string().required(),
        user_email : Joi.string().required().email(),
        user_phone : Joi.number().min(10),
        user_password: passwordComplexity(complexityOptions).required()

    });
    return UserSchema.validate(userObj);

};

const create = async function(req,res){
    console.log(req)
    const body = req.body;
    console.log(body)
    // Validate request
    if (!body) {
        res.status(400).send({
        message: "Content can not be empty!"
        });
    }
    const result = validate(body);
    // console.log(result.error);
    if(result.error){
        res.status(400).send(result.error.details[0].message);
        return;
    }

    const salt = await bcrypt.genSalt(10);
    const hashed = await bcrypt.hash(body.user_password,salt);
    body.user_password = hashed;

    // console.log(body);

    User.fetchOne({user_email : body.user_email}, (err,data) => {
        console.log(data);
        console.log(err)
        if (err){
            console.log(err);
            res.status(500).send({
                message:
                err.message || "Some error occurred while fetching the User."
                });
        }
            
        if(data.length > 0) res.status(400).send("User already exist");
        else{

            const user = _.pick(body,['user_email','user_first_name','user_last_name','user_password','user_phone']);
            //console.log("use"+user);
            // Save User in the database
            User.create(user, (err, data) => {
                console.log("1"+data);
                if (err){
                  res.status(500).send({
                    message:
                    err.message || "Some error occurred while creating the User."
                });
                }
                else {
                    const payload = {user_id: data.user_id , user_email : data.user_email};
                    const token = helperObj.generateAuthToken(payload,CONFIG.jwt_encryption);
                    res.header('x-auth-token',token).send(_.pick(data,['user_id','user_email']));
                }
            });
        }
    })
    
};



router.post("/user", create);

app.listen(CONFIG,()=>{
    console.log(`Listenning on port ${CONFIG} ........`);
});


