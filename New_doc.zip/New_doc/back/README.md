# so-dashboard-api
Apis to produce messages for other components of the system and stotre data to mysql database
