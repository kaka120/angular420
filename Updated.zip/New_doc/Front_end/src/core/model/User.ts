export interface User {
    userid: String,
    username: String,
    ticketpriority: String,
    ticketdescription: String,
    ticketcatagory:String,
    ticketsubcatagory:String,
    location:String
}