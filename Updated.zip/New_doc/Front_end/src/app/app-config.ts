export class MantisConfig {
  static layout = 'vertical';
  static isCollapseMenu = false;
  static font_family = 'public-sans'; // public-sans, Roboto, Poppins, Inter
}
